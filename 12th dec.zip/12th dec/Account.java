import java.util.HashSet;

public class Account {

String owner;

double balance;

public String getOwner() {

return owner;

}

public void setOwner(String owner) {

this.owner = owner;

}

public double getBalance() {

return balance;

}

public void setBalance(double balance) {

this.balance = balance;

}

public Account(String owner, double balance) {

this.owner = owner;

this.balance = balance;

}

public double init(){

return balance;

}

public void deposit(){

}

public void withdraw(){

}

public void print(){

}

}
