import express from "express";
import { engine } from "express-handlebars";

const app = express();
const port = process.env.PORT || 8080;

let m = {
  name: "Know",
  cat: "Them",
  people: [
    {
      id: 1,
      img: "https://static.vecteezy.com/system/resources/thumbnails/001/993/889/small/beautiful-latin-woman-avatar-character-icon-free-vector.jpg", 
      firstname: "Prathiksha",
      lastname: "Nataraj",
      role: "Developer",
      details: {
        meow: "Meow Meow Meow",
      },
    },
    {
      id: 2,
      img: "https://w1.pngwing.com/pngs/726/597/png-transparent-graphic-design-icon-customer-service-avatar-icon-design-call-centre-yellow-smile-forehead.png", 
      firstname: "Harshitha",
      lastname: "Nataraj",
      role: "Developer",
      details: {
        meow: "Meow Meow Meow",
      },
    },
    {
      id: 3,
      img: "https://static.vecteezy.com/system/resources/thumbnails/001/993/889/small/beautiful-latin-woman-avatar-character-icon-free-vector.jpg", 
      firstname: "Pallavi",
      lastname: "Raj",
      role: "Developer",
      details: {
        meow: "Meow Meow Meow",
      },
    },
  ],
};
app.engine("handlebars", engine());
app.set("view engine", "handlebars");
app.set("views", "./views");

app.get("/", (req, res) => {
  res.render("home", { data: m });
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.get("/details/:id", (req, res) => {
    m.people.forEach(e => {
        if(e.id == req.params.id) {
            res.render("details", {data: e});
        }
    });
});
app.listen(port, () => console.log(`App Started! ${port}`));
