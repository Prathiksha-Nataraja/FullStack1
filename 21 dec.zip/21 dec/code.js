function fun1()
{
   console.log("Fun1......")
}

function fun2()
{
   console.log("Fun2......")
}

function fun3()
{
   console.log("Fun3......")
}
module.exports ={
    fun1,fun2,fun3
}

//var roll=101;
//var name='vikas'
//var ob={
 //   roll, name
//}