function fun1()
{
    console.log("My Fun1 is executed")
}

var x =100

console.log(typeof x)
console.log(typeof fun1)

var abc = fun1

abc()