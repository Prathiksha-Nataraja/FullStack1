//Javascript object

//student : roll,name, age, marks


var student = [
    {
    roll:101,
    name:'Pratiksha' ,
    age:23,
    marks:{
        phy:89,
        che:78,
        math:85
    },
    address:[
        {
            location : "Madhugiri",city:"Tumkur", pincode:572132
        },
        {
            location: "Kengeri", city:"bangalore", pincode:560061
        }
    ]
},
roll:101,
name:'Pratiksha' ,
age:23,
marks:{
    phy:89,
    che:78,
    math:85
},
address:[
    {
        location : "Madhuri",city:"Tumkur", pincode:572132
    },
    {
        location: "Kengeri", city:"bangalore", pincode:560061
    }
]
}
]



for(let addr of student.address)
{
    console.log(addr.location,addr.city,addr.pincode)
}