var stud1={
    roll:101,
    name:'Pinku',
    age:27,
    marks:{
        phy:67,
        che:76,
        math:70
    }
}

//var stud2 = stud1

var stud2 = {
    ...stud1,
    marks: {
        ...stud1.marks
    }
  
}

console.log(stud1)

stud2.marks.che =100

console.log(stud1)

//stud2.age =30
//console.log(stud1)