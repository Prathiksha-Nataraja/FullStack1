var arr = [33,44,21,33,65,76,21]

console.log(arr)


arr.push(22)


console.log(arr)

var a = arr.pop()
console.log(a)

console.log(arr)