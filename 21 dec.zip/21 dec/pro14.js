
//Slice Function

var arr = [33,44,21,33,65,76,21]

console.log(arr)

//arr.splice(5,1)  
//arr.splice(4,2)

//arr.splice(3,2,100,300,555)
arr.splice(3,0,100,300,555)


console.log(arr)

