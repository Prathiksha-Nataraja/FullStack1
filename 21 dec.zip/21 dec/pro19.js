const fun = require('./code')
fun.fun1()
fun.fun2()
fun.fun3()