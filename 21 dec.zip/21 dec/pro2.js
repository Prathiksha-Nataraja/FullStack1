function fun1()
{
    console.log("My fun1 running")
}

function fun2()
{
    console.log("My fun2 running")
}

function hello(ob)
{
    console.log("good mornig")
   // console.log(ob)
   ob()
}

//var x=100

hello(fun1)
hello (fun2)