const {fun2} = require('./code')

fun2()