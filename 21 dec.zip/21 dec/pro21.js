class Employee
{
    constructor(empId,empName,empsalary)

    {
        this.empId=empId,
        this.empName=empName,
        this.empsalary=empsalary
    }
    show()
    {
        console.log(this.empId, this.empName,this.empsalary)
    }
}

var ob1=new Employee(101,"vikas",56000)
ob1.show()