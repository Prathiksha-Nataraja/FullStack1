class Employee
{
    //constructor(empId=0,empName='',empsalary=0.0)
    constructor(empId,empName,empsalary)
    {
        this.empId=empId,
        this.empName=empName,
        this.empsalary=empsalary
    }
    show()
    {
        console.log(this.empId, this.empName,this.empsalary)
    }
}

var ob1=new Employee(101,"vikas",56000)
var ob2 = new Employee();

ob1.show()
ob2.show()