class Demo
{
    fun1(){
        console.log("demo fun1...")
    }

    fun2(){
        console.log("demo fun2...")
    }
}
class Sample extends Demo{
    hello()
    {
        console.log("SAmple hello...")
    }


    fun2(){
        console.log("Sample fun2...")
    }
}

var ob = new Sample()
ob.fun1()
ob.fun2()
ob.hello()