function add(a,b)
{
    var c= a+b
    console.log("Addition :", c)
}
function mul(a,b)
{
    var c= a*b
    console.log("Multiplication :", c)
}
function hello(a,b,ob)
{
    console.log("good Morning")
    //add(a,b)
    ob(a,b)
    console.log("Hello everyone")
}

//hello(34,10,mul)
//hello(34,10,add)


hello(55,33,function(a,b)
{

var c = a-b
console.log("Result:",c)

})  //Annonymous function