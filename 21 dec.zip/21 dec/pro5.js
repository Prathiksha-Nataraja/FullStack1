//function hello()
//{
   // var x =100
  // function fun()
  // {
     //  console.log("fun fun")
//   }
 //   return fun
//}




function hello()
{
   return function()
   {
       console.log("fun fun")
   }
    
}

//var ob = hello()
//ob()


hello()()       