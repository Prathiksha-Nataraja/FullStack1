function fun1()
{
    console.log("Fun1 executed")
    console.log("Good morning...!")
}

function hello(ob)   //high ordeer function
{
    return function()
    {
        console.log("Torrry Harris")
        ob()
        console.log("Hello everyone")
    }
}

var abc = hello(fun1)
abc()