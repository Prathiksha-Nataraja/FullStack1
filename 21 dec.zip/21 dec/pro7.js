// Arrow function



//var fun1 = ()=>
//{
 //   console,log("Good Morning!")
//}



var add = (a,b) => a+b
var z = add(33,11)
console.log(z)