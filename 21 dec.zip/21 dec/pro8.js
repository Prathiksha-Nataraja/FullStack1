//Javascript object

//student : roll,name, age, marks


var student = {
    roll:101,
    name:'Pratiksha' ,
    age:23,
    marks:500
}

console.log(student, typeof student)
console.log(student.roll, student.name, student.age, student.marks)

var str = JSON.stringify(student)  //object to json
console.log(str, typeof str)

var obj = JSON.parse(str)         //json to object
console.log(obj, typeof obj)