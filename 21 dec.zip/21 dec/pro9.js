//Javascript object

//student : roll,name, age, marks


var student = {
    roll:101,
    name:'Pratiksha' ,
    age:23,
    marks:{
        phy:89,
        che:78,
        math:85
    },
    address:[
        {
            location : "Madhugiri",city:"Tumkur", pincode:572132
        },
        {
            location: "Kengeri", city:"bangalore", pincode:560061
        }
    ]
}

console.log(student, typeof student)
console.log(student.roll, student.name, student.age, student.marks)

var str = JSON.stringify(student)  //object to json
console.log(str, typeof str)

var obj = JSON.parse(str)         //json to object
console.log(obj, typeof obj)